class Calculator {
    constructor() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
        this.shouldResetScreen = false;

        this.display = {
            current: document.querySelector('.current-operand'),
            previous: document.querySelector('.previous-operand')
        };

        this.setupEventListeners();
        this.loadHistory();
    }

    setupEventListeners() {
        document.querySelectorAll('.number').forEach(button => {
            button.addEventListener('click', () => this.appendNumber(button.textContent));
        });

        document.querySelectorAll('.operator').forEach(button => {
            button.addEventListener('click', () => this.handleOperator(button.dataset.action));
        });

        document.querySelectorAll('.function').forEach(button => {
            button.addEventListener('click', () => this.handleFunction(button.dataset.action));
        });
    }

    async loadHistory() {
        try {
            const response = await fetch('/api/history');
            const history = await response.json();
            this.updateHistoryDisplay(history);
        } catch (error) {
            console.error('Error loading history:', error);
        }
    }

    updateHistoryDisplay(history) {
        const historyContainer = document.querySelector('.calculation-history');
        if (!historyContainer) return;

        historyContainer.innerHTML = history.map(calc => `
            <div class="history-item">
                <span class="expression">${calc.expression}</span>
                <span class="result">${calc.result}</span>
            </div>
        `).join('');
    }

    async saveCalculation(expression, result) {
        try {
            await fetch('/api/calculate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ expression, result })
            });
            this.loadHistory();
        } catch (error) {
            console.error('Error saving calculation:', error);
        }
    }

    appendNumber(number) {
        if (this.shouldResetScreen) {
            this.currentOperand = '';
            this.shouldResetScreen = false;
        }

        if (number === '.' && this.currentOperand.includes('.')) return;
        if (this.currentOperand === '0' && number !== '.') {
            this.currentOperand = number;
        } else {
            this.currentOperand += number;
        }
        this.updateDisplay();
    }

    handleOperator(operator) {
        if (this.currentOperand === '') return;

        if (this.previousOperand !== '') {
            this.calculate();
        }

        if (operator === 'equals') {
            const expression = `${this.previousOperand} ${this.getOperationSymbol()} ${this.currentOperand}`;
            const result = this.currentOperand;
            this.saveCalculation(expression, result);
            this.previousOperand = '';
            this.operation = undefined;
        } else {
            this.operation = operator;
            this.previousOperand = this.currentOperand;
            this.currentOperand = '';
        }
        this.updateDisplay();
    }

    handleFunction(func) {
        switch (func) {
            case 'clear':
                this.clear();
                break;
            case 'backspace':
                this.backspace();
                break;
            case 'percent':
                this.percent();
                break;
            case 'sqrt':
                this.sqrt();
                break;
        }
        this.updateDisplay();
    }

    calculate() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);

        if (isNaN(prev) || isNaN(current)) return;

        switch (this.operation) {
            case 'add':
                computation = prev + current;
                break;
            case 'subtract':
                computation = prev - current;
                break;
            case 'multiply':
                computation = prev * current;
                break;
            case 'divide':
                if (current === 0) {
                    this.currentOperand = 'Error';
                    this.shouldResetScreen = true;
                    return;
                }
                computation = prev / current;
                break;
            default:
                return;
        }

        this.currentOperand = computation.toString();
        this.operation = undefined;
        this.previousOperand = '';
        this.shouldResetScreen = true;
    }

    getOperationSymbol() {
        const operationSymbols = {
            'add': '+',
            'subtract': '−',
            'multiply': '×',
            'divide': '÷'
        };
        return operationSymbols[this.operation];
    }

    clear() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
    }

    backspace() {
        if (this.currentOperand.length === 1) {
            this.currentOperand = '0';
        } else {
            this.currentOperand = this.currentOperand.slice(0, -1);
        }
    }

    percent() {
        let value = parseFloat(this.currentOperand);
        if (!isNaN(value)) {
            this.currentOperand = (value / 100).toString();
        }
    }

    sqrt() {
        const value = parseFloat(this.currentOperand);
        if (!isNaN(value)) {
            if (value < 0) {
                this.currentOperand = 'Error';
            } else {
                const result = Math.sqrt(value);
                this.currentOperand = result.toString();
                const expression = `√(${value})`;
                this.saveCalculation(expression, result);
            }
            this.shouldResetScreen = true;
        }
    }

    updateDisplay() {
        this.display.current.textContent = this.currentOperand;
        if (this.operation) {
            const operationSymbols = {
                'add': '+',
                'subtract': '−',
                'multiply': '×',
                'divide': '÷'
            };
            this.display.previous.textContent = `${this.previousOperand} ${operationSymbols[this.operation]}`;
        } else {
            this.display.previous.textContent = this.previousOperand;
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new Calculator();
});